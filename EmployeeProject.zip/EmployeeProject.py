from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
from typing import List
from pymongo import MongoClient
from bson import ObjectId

app = FastAPI()

MONGO_URL = "mongodb://localhost:27017"
DATABASE_NAME = "office_management"
COLLECTION_NAME = "employees"

client = MongoClient(MONGO_URL)
db = client[DATABASE_NAME]
collection = db[COLLECTION_NAME]


class Project(BaseModel):
    name: str
    role: str


class EmployeeProject(BaseModel):
    id: str
    projects: List[Project] = []


@app.put("/employee/{employee_id}/promotion", response_model=dict)
def promote_employee(employee_id: str, new_position: str = Query(...), new_salary: float = Query(...)):
    employee = collection.find_one({"_id": ObjectId(employee_id)})
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")

    update_data = {
        "position": new_position,
        "salary": new_salary
    }

    collection.update_one({"_id": ObjectId(employee_id)}, {"$set": update_data})
    return {"message": "Employee promoted successfully"}


@app.post("/employee/{employee_id}/project", response_model=dict)
def add_employee_to_project(employee_id: str, project: Project):
    employee = collection.find_one({"_id": ObjectId(employee_id)})
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")

    if "projects" not in employee:
        employee["projects"] = []

    employee["projects"].append(project.dict())
    collection.update_one({"_id": ObjectId(employee_id)}, {"$set": {"projects": employee["projects"]}})
    return {"message": "Project added successfully"}


@app.get("/employee/{employee_id}/projects", response_model=EmployeeProject)
def get_employee_projects(employee_id: str):
    employee = collection.find_one({"_id": ObjectId(employee_id)})
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")

    return EmployeeProject(id=str(employee["_id"]), projects=employee.get("projects", []))